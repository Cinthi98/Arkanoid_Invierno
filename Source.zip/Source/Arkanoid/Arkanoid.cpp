// Copyright Epic Games, Inc. All Rights Reserved.

#include "Arkanoid.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Arkanoid, "Arkanoid" );
